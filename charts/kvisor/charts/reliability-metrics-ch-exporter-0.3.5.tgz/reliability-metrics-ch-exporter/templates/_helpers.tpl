{{/*
Expand the name of the chart.
*/}}
{{- define "clickhouse.name" -}}
{{- default "clickhouse" .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
When used as a subchart of kvisor (alias: clickhouse), fullnameOverride is
typically set by the parent to produce consistent naming (e.g. castai-kvisor-clickhouse).
*/}}
{{- define "clickhouse.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default "clickhouse" .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label.
*/}}
{{- define "clickhouse.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "clickhouse.labels" -}}
helm.sh/chart: {{ include "clickhouse.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for the dev ClickHouse StatefulSet.
*/}}
{{- define "clickhouse.selectorLabels" -}}
app.kubernetes.io/name: {{ include "clickhouse.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ClickHouse connection address.
Resolves based on: external > install (operator CR) > enabled (StatefulSet).
*/}}
{{- define "clickhouse.address" -}}
{{- if (and .Values.external .Values.external.enabled) -}}
{{ .Values.external.address }}
{{- else if (and .Values.install .Values.install.enabled) -}}
{{- /* ClickHouseInstallation serviceTemplate creates: <generateName>.<namespace>.svc.cluster.local */ -}}
{{ include "clickhouse.fullname" . }}.{{ .Release.Namespace }}.svc.cluster.local:9000
{{- end -}}
{{- end -}}

{{/*
ClickHouse credentials — resolves external overrides vs auth defaults.
These helpers return plain string values for backward compatibility.
For env vars that support valueFrom, use the *Env helpers below.
*/}}
{{- define "clickhouse.username" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.username -}}
{{ .Values.external.username }}
{{- else -}}
{{- $username := .Values.auth.username -}}
{{- if kindIs "string" $username -}}
{{ $username }}
{{- else -}}
{{- /* If it's a map with valueFrom, we can't resolve it here - return empty */ -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "clickhouse.password" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.password -}}
{{ .Values.external.password }}
{{- else -}}
{{- $password := .Values.auth.password -}}
{{- if kindIs "string" $password -}}
{{ $password }}
{{- else -}}
{{- /* If it's a map with valueFrom, we can't resolve it here - return empty */ -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "clickhouse.database" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.database -}}
{{ .Values.external.database }}
{{- else -}}
{{- $database := .Values.auth.database -}}
{{- if kindIs "string" $database -}}
{{ $database }}
{{- else -}}
{{- /* If it's a map with valueFrom, we can't resolve it here - return empty */ -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
ClickHouse credentials for environment variables — supports both plain values and valueFrom.
Returns the complete env var definition (either "value: X" or "valueFrom: ...").
Usage in templates:
  - name: CLICKHOUSE_USERNAME
    {{- include "clickhouse.usernameEnv" . | nindent 4 }}
*/}}
{{- define "clickhouse.usernameEnv" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.username -}}
value: {{ .Values.external.username | quote }}
{{- else -}}
{{- $username := .Values.auth.username -}}
{{- if kindIs "string" $username -}}
value: {{ $username | quote }}
{{- else if and (kindIs "map" $username) $username.valueFrom -}}
{{- toYaml $username | nindent 0 }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "clickhouse.passwordEnv" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.password -}}
value: {{ .Values.external.password | quote }}
{{- else -}}
{{- $password := .Values.auth.password -}}
{{- if kindIs "string" $password -}}
value: {{ $password | quote }}
{{- else if and (kindIs "map" $password) $password.valueFrom -}}
{{- toYaml $password | nindent 0 }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "clickhouse.databaseEnv" -}}
{{- if and (and .Values.external .Values.external.enabled) .Values.external.database -}}
value: {{ .Values.external.database | quote }}
{{- else -}}
{{- $database := .Values.auth.database -}}
{{- if kindIs "string" $database -}}
value: {{ $database | quote }}
{{- else if and (kindIs "map" $database) $database.valueFrom -}}
{{- toYaml $database | nindent 0 }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Check if any ClickHouse is configured.
*/}}
{{- define "clickhouse.isConfigured" -}}
{{- or (and .Values.external .Values.external.enabled) (and .Values.install .Values.install.enabled) -}}
{{- end -}}

{{/*
Image tag — falls back to Chart.AppVersion.
*/}}
{{- define "clickhouse.imageTag" -}}
{{- default .Chart.AppVersion .Values.image.tag }}
{{- end }}

{{/*
CASTAI API key env source.
*/}}
{{- define "clickhouse.castaiApiKeyEnv" -}}
{{- if .Values.castai.apiKey -}}
- name: CASTAI_API_KEY
  value: {{ .Values.castai.apiKey | quote }}
{{- else if .Values.castai.apiKeySecretRef -}}
- name: CASTAI_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.castai.apiKeySecretRef }}
      key: API_KEY
{{- end -}}
{{- end -}}

{{/*
CASTAI cluster ID env.
Resolution: global.castai.clusterID > castai.clusterID > configMapRef > secretRef
*/}}
{{- define "clickhouse.castaiClusterIDEnv" -}}
{{- $clusterID := coalesce (dig "castai" "clusterID" "" (.Values.global | default dict)) .Values.castai.clusterID -}}
{{- if $clusterID -}}
- name: CASTAI_CLUSTER_ID
  value: {{ $clusterID | quote }}
{{- else if and .Values.castai.clusterIdConfigMapRef .Values.castai.clusterIdConfigMapRef.name -}}
- name: CASTAI_CLUSTER_ID
  valueFrom:
    configMapKeyRef:
      name: {{ .Values.castai.clusterIdConfigMapRef.name }}
      key: {{ .Values.castai.clusterIdConfigMapRef.key | default "CLUSTER_ID" }}
{{- else if and .Values.castai.clusterIdSecretKeyRef .Values.castai.clusterIdSecretKeyRef.name -}}
- name: CASTAI_CLUSTER_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.castai.clusterIdSecretKeyRef.name }}
      key: {{ .Values.castai.clusterIdSecretKeyRef.key | default "CLUSTER_ID" }}
{{- end -}}
{{- end -}}

{{/*
Credentials Secret name — used by OTel collectors in the parent chart.
*/}}
{{- define "clickhouse.credentialsSecretName" -}}
{{ include "clickhouse.fullname" . }}-credentials
{{- end }}
