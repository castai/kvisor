# CAST AI Reliability Metrics Helm Chart

This chart manages the complete reliability metrics infrastructure for CAST AI kvisor, consisting of three main components:

- **In-cluster ClickHouse** - Database for metrics storage (via Altinity operator)
- **Schema Migration** - Goose-based database migration system
- **Metrics Exporter** - Exports aggregated metrics from ClickHouse to CAST AI

## Components

### 1. In-cluster ClickHouse (`in-cluster-clickhouse`)

Production-grade ClickHouse deployment managed by the [Altinity ClickHouse Operator](https://github.com/Altinity/clickhouse-operator).

**Features:**
- Automatic pod management and recovery
- Built-in monitoring and metrics
- Schema versioning and upgrades
- Persistent storage with configurable size
- Resource limits and requests

**Configuration:**
```yaml
operator:
  enabled: true  # Install Altinity operator

install:
  enabled: true  # Deploy ClickHouse via operator CRD
  resources:
    requests:
      cpu: 500m
      memory: 4Gi
    limits:
      memory: 8Gi
  persistence:
    size: 50Gi
```

### 2. Schema Migration (`schema-migration`)

Goose-based migration system that manages ClickHouse database schema.

**Features:**
- Runs as a Kubernetes Job before ClickHouse Installation
- Embeds SQL migrations in the binary
- Idempotent - safe to re-run
- Automatic rollback on failure

**Migrations location:** `cmd/migrate/migrations/otel/`

**Configuration:**
```yaml
migrate:
  enabled: true  # Run migrations (default: true)
  image:
    repository: us-east4-docker.pkg.dev/castai-hub/kubecast/reliability-metrics-ch-exporter-migrate
    tag: ""  # defaults to Chart.AppVersion
```

### 3. Metrics Exporter (`exporter`)

Sidecar container in the ClickHouse pod that exports aggregated metrics to CAST AI.

**Features:**
- Runs as sidecar in ClickHouse pod (zero network latency)
- Exports silver tables (pre-aggregated metrics)
- Automatic retry and backpressure handling
- Prometheus metrics on `:8080/metrics`

**Configuration:**
```yaml
exporter:
  enabled: true
  image:
    repository: us-east4-docker.pkg.dev/castai-hub/kubecast/reliability-metrics-ch-exporter
    tag: ""  # defaults to Chart.AppVersion
  grpcAddr: "telemetry.cast.ai:443"
  resources:
    requests:
      memory: 64Mi
    limits:
      memory: 256Mi
```

## Installation

### As a subchart of castai-kvisor (recommended)

In `kvisor/Chart.yaml`:
```yaml
dependencies:
  - name: reliability-metrics
    version: "0.2.0"
    repository: "https://charts.cast.ai"  # or OCI registry
    condition: reliabilityMetrics.enabled
    alias: reliabilityMetrics
```

In `kvisor/values.yaml`:
```yaml
reliabilityMetrics:
  enabled: true
  # CAST AI credentials
  castai:
    apiKeySecretRef: "castai-kvisor"
    clusterID: "your-cluster-id"
    grpcAddr: "telemetry.cast.ai:443"
  # In-cluster ClickHouse
  operator:
    enabled: true
  install:
    enabled: true
    resources:
      requests:
        cpu: 500m
        memory: 4Gi
      limits:
        memory: 8Gi
    persistence:
      size: 50Gi
  # Authentication
  auth:
    database: "metrics"
    username: "kvisor"
    password: "kvisor"
  # Exporter
  exporter:
    enabled: true
    grpcAddr: "telemetry.cast.ai:443"
```

Then deploy:
```bash
helm dependency update ./charts/kvisor
helm upgrade castai-kvisor ./charts/kvisor -n castai-agent \
  -f charts/kvisor/obi-values.yaml \
  --set castai.apiKey=<key> \
  --set castai.clusterID=<id>
```

### Standalone installation

```bash
helm install reliability-metrics ./chart -n reliability-metrics --create-namespace \
  --set enabled=true \
  --set operator.enabled=true \
  --set install.enabled=true \
  --set castai.apiKey=<key> \
  --set castai.clusterID=<id> \
  --set castai.grpcAddr=telemetry.cast.ai:443
```

## Deployment Modes

### Mode 1: In-cluster ClickHouse (Production)

Uses Altinity operator to manage ClickHouse in Kubernetes.

```yaml
operator:
  enabled: true
install:
  enabled: true
```

**Resources created:**
- ClickHouseOperator Deployment (manages ClickHouse lifecycle)
- ClickHouseInstallation CR (defines ClickHouse cluster)
- StatefulSet (managed by operator, contains ClickHouse + exporter)
- Service (for ClickHouse access)
- ConfigMaps (for ClickHouse configuration)

### Mode 2: External ClickHouse

Point to an existing ClickHouse instance outside the cluster.

```yaml
external:
  enabled: true
  address: "clickhouse.example.com:9000"
  username: "custom_user"  # optional override
  password: "custom_pass"  # optional override
  database: "custom_db"    # optional override
```

**Note:** Migration and operator are skipped in external mode. Only exporter runs.

## Configuration

### Authentication

```yaml
auth:
  database: "metrics"  # ClickHouse database name
  username: "kvisor"   # ClickHouse username
  password: "kvisor"   # ClickHouse password
```

### CAST AI Integration

```yaml
castai:
  # Option 1: Direct API key
  apiKey: "your-api-key"

  # Option 2: Reference existing Secret
  apiKeySecretRef: "castai-kvisor"  # Secret containing 'API_KEY' key

  # Cluster ID
  clusterID: "your-cluster-id"

  # CAST AI gRPC endpoint
  grpcAddr: "telemetry.cast.ai:443"
```

### Resources

```yaml
install:
  resources:
    requests:
      cpu: 500m
      memory: 4Gi
    limits:
      memory: 8Gi
  persistence:
    size: 50Gi
    storageClass: ""  # use default storage class

exporter:
  resources:
    requests:
      memory: 64Mi
    limits:
      memory: 256Mi
```

### Advanced Configuration

```yaml
# ClickHouse server image
image:
  repository: clickhouse/clickhouse-server
  tag: "25.1.2.5-alpine"
  pullPolicy: IfNotPresent

# Node selection
nodeSelector: {}
tolerations: []
affinity: {}

# Operator configuration
operator:
  image:
    repository: altinity/clickhouse-operator
    tag: "0.26.0"
  metricsExporter:
    repository: altinity/metrics-exporter
    pullPolicy: IfNotPresent
```

## Troubleshooting

### Check ClickHouse pod status

```bash
kubectl get pods -n castai-agent | grep clickhouse
```

Expected output:
```
castai-kvisor-clickhouse-operator-xxx   2/2   Running
chi-castai-kvisor-clickhouse-otel-0-0-0  2/2   Running
```

### Check exporter logs

```bash
kubectl logs -n castai-agent chi-castai-kvisor-clickhouse-otel-0-0-0 -c ch-exporter
```

Healthy output:
```
level=info msg="rows exported to CastAI" rows=100 table=reliability_metrics_gauge
level=info msg="data is synced to CastAI" table=reliability_metrics_gauge
```

### Check ClickHouse connectivity

```bash
kubectl exec -n castai-agent chi-castai-kvisor-clickhouse-otel-0-0-0 -c clickhouse -- \
  clickhouse-client --query "SELECT version()"
```

### Common Issues

**1. Exporter authentication errors**

```
error="rpc error: code = Unauthenticated desc = authentication token not found"
```

**Solution:** Ensure CAST AI credentials are set:
```yaml
castai:
  apiKeySecretRef: "castai-kvisor"  # or apiKey: "..."
  clusterID: "your-cluster-id"
```

**2. Migration job fails**

Check migration logs:
```bash
kubectl logs -n castai-agent castai-kvisor-clickhouse-migrate-xxx
```

**Solution:** Ensure ClickHouse is ready and credentials are correct.

**3. ClickHouse pod ImagePullBackOff**

Check image repository and credentials:
```yaml
image:
  repository: clickhouse/clickhouse-server
  tag: "25.1.2.5-alpine"
```

## Credentials Secret

The chart automatically creates a credentials Secret used by OTel collectors:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: castai-kvisor-clickhouse-credentials
data:
  address: <base64>    # ClickHouse address
  database: <base64>   # Database name
  username: <base64>   # Username
  password: <base64>   # Password
```

This Secret is referenced by kvisor agent and controller OTel collector containers.

## Values Reference

| Parameter | Description | Default |
|-----------|-------------|---------|
| `enabled` | Master switch for the chart | `false` |
| `operator.enabled` | Install Altinity operator | `false` |
| `install.enabled` | Deploy ClickHouse via operator | `false` |
| `external.enabled` | Use external ClickHouse | `false` |
| `auth.database` | ClickHouse database name | `"kvisor"` |
| `auth.username` | ClickHouse username | `"kvisor"` |
| `auth.password` | ClickHouse password | `"kvisor"` |
| `exporter.enabled` | Enable metrics exporter | `false` |
| `exporter.grpcAddr` | CAST AI gRPC endpoint | `""` |
| `migrate.enabled` | Run schema migrations | `true` |
| `castai.apiKey` | CAST AI API key (direct) | `""` |
| `castai.apiKeySecretRef` | CAST AI API key (from Secret) | `""` |
| `castai.clusterID` | CAST AI cluster ID | `""` |
| `castai.grpcAddr` | CAST AI gRPC endpoint | `""` |
